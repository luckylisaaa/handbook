# Astra Design System v1.0

> *Per Aspera Ad Astra.*  
> 穿越艱辛，抵達繁星。

---

## 📖 這是什麼？

Astra 品牌的**完整視覺資產系統**。所有場景、所有裝置、所有輸出形式的素材都在這裡。

**使用規則：** 複製、貼上、直接用。不需要重新生成。

---

## 📁 資料夾說明

| 資料夾 | 用途 | 放在哪 |
|---|---|---|
| `01_Colors/` | 色彩系統 | 給設計師 / 工程師 |
| `02_Logo/` | 主符號（SVG+PNG+ICO）| 任何場景的源頭 |
| `03_Favicons/` | 網站圖示組 | GitHub / 網站 |
| `04_Documents/` | 文件浮水印 | Word / Google Docs |
| `05_Notion/` | Notion 封面 | Notion 頁面 |
| `06_Social/` | 社群素材 | IG / FB / LinkedIn / Email |
| `07_Video/` | 影片素材 | 片頭片尾、下三分之一 |
| `08_Print/` | 印刷素材 | 名片、海報、DM |

---

## 🎨 色彩系統

### 品牌核心（必用）

| 色名 | HEX | 使用場景 |
|---|---|---|
| 🟫 **暖米底 Cream** | `#F7F0E8` | 主背景、icon 外框 |
| 🔴 **品牌紅 Red** | `#A51820` | 主色、icon 方塊、按鈕 |
| ⚪ **米白 White** | `#FDFBF8` | 符號、深色背景文字 |

### 中性色

| 色名 | HEX | 使用場景 |
|---|---|---|
| ⬛ **主文字** | `#1A1A1A` | 主要文字 |
| ⬛ **次文字** | `#666666` | 次要文字、說明 |
| ⚫ **分隔線** | `#E0D8CF` | 邊框、分隔線 |

### 深色模式（自動切換）

| 色名 | HEX | 使用場景 |
|---|---|---|
| ⬛ **深底** | `#1A0E0F` | 深色主背景 |
| ⬛ **深卡片** | `#2A1A1C` | 深色卡片 |
| 🔴 **亮紅** | `#C63844` | 深色模式主色 |

---

## 📐 檔案格式對照表

### 🖥 網站用

| 檔名 | 尺寸 | 用途 |
|---|---|---|
| `favicon.ico` | 16+32+48 | 瀏覽器分頁 |
| `favicon-16x16.png` | 16×16 | 瀏覽器 |
| `favicon-32x32.png` | 32×32 | 瀏覽器書籤 |
| `apple-touch-icon.png` | 180×180 | iPhone 加入主畫面 |
| `android-chrome-192x192.png` | 192×192 | Android 主畫面 |
| `android-chrome-512x512.png` | 512×512 | PWA 啟動畫面 |
| `site.webmanifest` | — | PWA 配置檔 |

### 📱 裝置顯示

| 情境 | 用哪個檔 |
|---|---|
| iPhone 加入主畫面 | `apple-touch-icon.png` (180×180) |
| Android 加入主畫面 | `android-chrome-192x192.png` |
| Windows 任務列 | `favicon.ico` |
| Mac Safari 分頁 | `favicon-16x16.png` |

### 📄 文件 / Notion / 簡報

| 情境 | 用哪個檔 |
|---|---|
| Notion icon（頁面小圖示）| `Astra_192.png` 或上傳 SVG |
| Notion 封面 | `Astra_notion_cover.png` (2880×720) |
| Google Docs / Word 浮水印 | `Astra_watermark.png` |
| Keynote / PowerPoint | `Astra_1024.png` (高解析) |
| 印刷名片 | SVG 母檔 |

### 🎬 影片

| 情境 | 用哪個檔 |
|---|---|
| 片尾卡 | `Astra_endcard_1920x1080.png` |
| 下三分之一 | `Astra_lowerthird.png` |
| 片頭 logo | `Astra_1024.png` |

### 🌐 社群

| 平台 | 用哪個檔 |
|---|---|
| IG 大頭貼 | `Astra_IG_avatar.png` (1080×1080) |
| FB 封面 | `Astra_FB_cover.png` (1640×624) |
| Email 簽名 | `Astra_email_signature.png` |

---

## ✅ 使用規則（DO）

1. **保持最小尺寸**：不要小於 16×16 顯示
2. **保持原始比例**：不要拉扁或壓縮
3. **周圍留白**：icon 周圍至少留一個 icon 寬度的呼吸空間
4. **顏色遵守**：不要自行更改品牌三色
5. **優先用 SVG**：能用 SVG 的地方就用 SVG（可無限縮放）

---

## ❌ 禁止事項（DON'T）

1. ❌ 不要改變品牌紅的色號
2. ❌ 不要把 icon 放在與品牌調性衝突的背景（例如螢光色）
3. ❌ 不要在 icon 上加特效（陰影、漸層、描邊）
4. ❌ 不要倒置、旋轉 icon
5. ❌ 不要把不同工具的 icon 合在一起用

---

## 🎯 輕重緩急系統

### 方法一：透明度

```css
.message-important { opacity: 1.0; }   /* 重要 */
.message-regular   { opacity: 0.7; }   /* 一般 */
.message-light     { opacity: 0.4; }   /* 次要 */
```

### 方法二：粗細變體

- `icon.svg` → Regular 版（日常）
- `icon_line.svg` → Light 版（次要）
- 可另做 Bold 加粗版（強調）

### 方法三：色彩語意

- 🔴 `#A51820` → 主色、強調、警告
- 🟢 `#2E7D32` → 成功訊息
- 🟠 `#E67E22` → 警告注意
- 🔵 `#3178C6` → 資訊提示

---

## 🌓 深色模式自動切換

HTML 範例：

```html
<picture>
  <source srcset="Astra_dark.svg" media="(prefers-color-scheme: dark)">
  <img src="Astra.svg" alt="Astra">
</picture>
```

CSS 範例：

```css
@media (prefers-color-scheme: dark) {
  .astra-icon {
    filter: invert(1);
  }
}
```

---

## 📌 版本歷史

| 版本 | 日期 | 內容 |
|---|---|---|
| v1.0 | 2026-04 | 六大工具主符號 · 完整資料夾結構 |
| v1.1 | 規劃中 | Lottie 動態版 · 3D 質感版 |
| v2.0 | 規劃中 | 其他分頁 19 個 icon |

---

## 📞 品牌聯絡

- 🌐 **主站：** astra.tw（或 luckylisaaa.github.io/handbook/）
- ✉️ **聯絡：** hello@astra.tw

---

*「我們不做手作坊，我們建立宇宙。」*

**Astra · Per Aspera Ad Astra · 2026**
