# ICS 品牌素材包 · 設計備忘

**版本**：v1.0
**建立日期**：2026-04-23
**適用於**：luckylisaaa.github.io 所有子網站

---

## 📦 這個素材包裡有什麼

```
ics-brand-assets/
├── icons/            ← 6 套 icon（30 個 PNG + 6 個 SVG + 6 個 ICO）
│   ├── ICS/          ICS 總品牌
│   ├── H/            Handbook
│   ├── M/            Matrix
│   ├── S/            Scripts
│   ├── B/            Brand
│   └── T/            Tasks
├── colors/           ← 色票（4 種格式）
├── html_snippets/    ← HTML 可複製片段
└── docs/             ← 文件（就是這個 README）
```

---

## 🎨 品牌視覺規範

### 核心概念
- **暖米底（#FDFBF8）+ 正紅方塊（#A51820）+ 白色襯線字母 + 金線裝飾（#D4A574）**
- 不同工具只換「中央符號」，背景和主色不變
- 符號保持幾何化、極簡化（避免寫實插圖）
- 未來做 10 個工具都會像同一系列

### 主色 · #A51820 深玫瑰紅
品牌的基準色。用於按鈕、標題強調、連結底線、重要分隔線。

### 輔助色系
- 深紅 `#7A1018`：漸層暗端、深背景
- 亮紅 `#C02030`：hover 狀態、強調
- 金色 `#D4A574`：icon 裝飾、點綴（用量少）

### 背景色系
- 暖雪白 `#FDFBF8`：頁面底色
- 卡片底 `#F4F1EC`：卡片、區塊
- AI 重點粉 `#FAE8EA`：AI 相關提示框
- Hero 底 `#FDF3F4`：Hero 區的淡紅底

### 文字色系
- 微咖黑 `#2A1A1C`：內文主色（不用純黑）
- 輔助字 `#7A5A5E`：副標、說明
- 淡化字 `#B09498`：弱化、版權

---

## 🖌️ 字體

| 用途 | 字體 | Weight |
|---|---|---|
| 標題 | Noto Serif TC | 500 / 700 / 900 |
| 內文 | Noto Sans TC | 400 / 500 / 700 / 900 |
| 程式碼 | JetBrains Mono | - |

**Google Fonts 引用**：
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;500;700;900&family=Noto+Serif+TC:wght@500;700;900&display=swap" rel="stylesheet">
```

---

## 🎯 Icon 設計邏輯

### 結構
```
┌─────────────────────────┐  ← 外框：圓角方塊（rx=22%）
│                         │
│   ╰─── 金線 L 角 ───╯   │  ← 右上金線裝飾
│                         │
│         字母            │  ← 白色襯線，中央對齊
│        （白色）          │
│                         │
│   ╰─── 金線 L 角 ───╯   │  ← 左下金線裝飾
│                         │
└─────────────────────────┘
   背景：深紅漸層 135°
   從 #B51E28 → #7A1018
```

### 字母大小比例
- 單字母（H / M / S / B / T）：佔方塊高度的 60%
- 三字母（ICS）：佔方塊高度的 32%

### 尺寸說明
| 尺寸 | 用途 |
|---|---|
| 16×16 | favicon.ico 最小相容 |
| 32×32 | favicon 標準 |
| 180×180 | iOS apple-touch-icon |
| 192×192 | Android PWA |
| 512×512 | PWA 高解析 / 分享圖 / 母版 |
| SVG | 無限縮放、可改色（母版）|

---

## 🧩 使用範例

### 1 · 網站 favicon
```html
<!-- 放在 <head> 裡 -->
<link rel="icon" type="image/png" sizes="32x32" href="icons/H/icon-h-32.png">
<link rel="icon" type="image/svg+xml" href="icons/H/icon-h.svg">
<link rel="apple-touch-icon" href="icons/H/icon-h-180.png">
<link rel="shortcut icon" href="icons/H/favicon.ico">
```

### 2 · PWA manifest.json
```json
{
  "name": "Handbook",
  "theme_color": "#A51820",
  "icons": [
    { "src": "icons/H/icon-h-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "icons/H/icon-h-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

### 3 · 清單裡的小 icon
看 `html_snippets/icon-usage.html` 有完整範例。

### 4 · 浮動導覽
完整 code 在 `html_snippets/floating-nav.html`。
貼進任何網站 `</body>` 之前就會出現右下角 + 按鈕。

---

## ⚠️ 使用原則

### 該做的 ✓
- icon 背景永遠用深紅漸層
- 字母永遠用白色襯線體
- 金線裝飾保持細（約背景尺寸 0.4%）
- 圓角比例 22%（維持柔和感）

### 不該做的 ✗
- ✗ 不要換 icon 背景色（會失去系列感）
- ✗ 不要用黑色字母（對比會刺眼）
- ✗ 不要加陰影、發光、3D 效果（保持極簡）
- ✗ 不要把字母換成 emoji 或複雜圖形

---

## 📅 版本歷史

| 版本 | 日期 | 內容 |
|---|---|---|
| v1.0 | 2026-04-23 | 六大工具 icon + 色票 + HTML 片段 |
| v1.1 | 規劃中 | Lottie 動態版、3D 質感 |
| v2.0 | 規劃中 | 19 個分頁 icon 全套重設計 |

---

## 🔗 相關網站

- **首頁**：https://luckylisaaa.github.io/
- **Handbook**：https://luckylisaaa.github.io/handbook/
- **Matrix**：https://luckylisaaa.github.io/matrix/
- **Scripts**：https://luckylisaaa.github.io/script-generator/
- **Brand**：https://luckylisaaa.github.io/brand-guidelines/
- **Tasks**：https://luckylisaaa.github.io/tasks/

---

**Inspire · Create · Shine**
*Finding beauty. Making it move.*
